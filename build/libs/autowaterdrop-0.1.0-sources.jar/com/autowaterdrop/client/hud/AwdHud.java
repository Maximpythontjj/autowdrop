package com.autowaterdrop.client.hud;

import com.autowaterdrop.client.config.AwdConfig;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class AwdHud {
    private static boolean ready;

    public static void setReady(boolean isReady) {
        ready = isReady;
    }

    public static void render(class_332 draw) {
        if (!AwdConfig.get().showHud) return;
        class_310 client = class_310.method_1551();
        if (client == null || client.method_22683() == null) return;
        int width = client.method_22683().method_4486();
        int height = client.method_22683().method_4502();
        int size = 12;
        int x = width - size - 6;
        int y = height - size - 28;

        int color = ready ? 0x8800FF00 : 0x88FF0000;
        draw.method_25294(x, y, x + size, y + size, color);
    }
}

