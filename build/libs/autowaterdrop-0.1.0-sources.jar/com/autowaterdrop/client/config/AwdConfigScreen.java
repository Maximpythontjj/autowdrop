package com.autowaterdrop.client.config;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class AwdConfigScreen extends class_437 {
    private final class_437 parent;

    public AwdConfigScreen(class_437 parent) {
        super(class_2561.method_43470("Auto WaterDrop Settings"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int y = this.field_22790 / 6;
        int x = this.field_22789 / 2 - 100;

        // Min fall height slider
        this.method_37063(new SimpleIntSlider(x, y, 200, 20, class_2561.method_43470("Min height: "), AwdConfig.get().minFallHeightBlocks, 3, 20, value -> {
            AwdConfig.get().minFallHeightBlocks = value;
            AwdConfig.save();
        }));
        y += 24;

        // Activation lead slider
        this.method_37063(new SimpleIntSlider(x, y, 200, 20, class_2561.method_43470("Lead ticks: "), AwdConfig.get().activationLeadTicks, 1, 6, value -> {
            AwdConfig.get().activationLeadTicks = value;
            AwdConfig.save();
        }));
        y += 24;

        // Auto pickup slider (0=off)
        this.method_37063(new SimpleIntSlider(x, y, 200, 20, class_2561.method_43470("Auto pickup ticks: "), AwdConfig.get().autoPickupTicks, 0, 6, value -> {
            AwdConfig.get().autoPickupTicks = value;
            AwdConfig.save();
        }));
        y += 24;

        // Toggles
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Restore slot: " + AwdConfig.get().restorePreviousSlot), btn -> {
            AwdConfig.get().restorePreviousSlot = !AwdConfig.get().restorePreviousSlot;
            btn.method_25355(class_2561.method_43470("Restore slot: " + AwdConfig.get().restorePreviousSlot));
            AwdConfig.save();
        }).method_46434(x, y, 200, 20).method_46431());
        y += 24;

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Neighbor search: " + AwdConfig.get().searchNeighborPlacements), btn -> {
            AwdConfig.get().searchNeighborPlacements = !AwdConfig.get().searchNeighborPlacements;
            btn.method_25355(class_2561.method_43470("Neighbor search: " + AwdConfig.get().searchNeighborPlacements));
            AwdConfig.save();
        }).method_46434(x, y, 200, 20).method_46431());
        y += 24;

        this.method_37063(class_4185.method_46430(class_2561.method_43470("HUD: " + AwdConfig.get().showHud), btn -> {
            AwdConfig.get().showHud = !AwdConfig.get().showHud;
            btn.method_25355(class_2561.method_43470("HUD: " + AwdConfig.get().showHud));
            AwdConfig.save();
        }).method_46434(x, y, 200, 20).method_46431());
        y += 24;

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Safe mode extra tick: " + AwdConfig.get().safeModeExtraTick), btn -> {
            AwdConfig.get().safeModeExtraTick = !AwdConfig.get().safeModeExtraTick;
            btn.method_25355(class_2561.method_43470("Safe mode extra tick: " + AwdConfig.get().safeModeExtraTick));
            AwdConfig.save();
        }).method_46434(x, y, 200, 20).method_46431());
        y += 24;

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Back"), btn -> {
            class_310.method_1551().method_1507(parent);
        }).method_46434(x, y, 200, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context, mouseX, mouseY, delta);
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 15, 0xFFFFFF);
    }

    private static final class SimpleIntSlider extends class_357 {
        private final int min;
        private final int max;
        private final java.util.function.IntConsumer consumer;
        private final String labelPrefix;

        SimpleIntSlider(int x, int y, int w, int h, class_2561 label, int current, int min, int max, java.util.function.IntConsumer consumer) {
            super(x, y, w, h, class_2561.method_43470("") , 0.0);
            this.min = min;
            this.max = max;
            this.consumer = consumer;
            this.labelPrefix = label.getString();
            this.field_22753 = (current - min) / (double)(max - min);
            method_25346();
        }

        @Override
        protected void method_25346() {
            int v = getInt();
            method_25355(class_2561.method_43470(labelPrefix + v));
        }

        @Override
        protected void method_25344() {
            consumer.accept(getInt());
        }

        private int getInt() {
            return (int)Math.round(min + field_22753 * (max - min));
        }
    }
}

