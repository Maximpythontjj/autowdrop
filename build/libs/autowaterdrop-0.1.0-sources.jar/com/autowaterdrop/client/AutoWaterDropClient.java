package com.autowaterdrop.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_1268;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_746;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import org.lwjgl.glfw.GLFW;
import com.autowaterdrop.client.util.LatencyUtil;
import com.autowaterdrop.client.config.AwdConfig;
import com.autowaterdrop.client.hud.AwdHud;
import com.autowaterdrop.client.util.InventoryUtil;
import com.autowaterdrop.client.util.PlacementUtil;

public class AutoWaterDropClient implements ClientModInitializer {
    private static final double FALL_VELOCITY_THRESHOLD = -0.5; // blocks/tick

    private double fallStartY = Double.NaN;
    private int ticksUntilPlace = -1;
    private int previousSelectedSlot = -1;
    private boolean scheduledPickup = false;
    private int pickupDelayTicks = 0;
    private boolean wasOnGround = true;

    @Override
    public void onInitializeClient() {
        AwdConfig.load();

        class_304 cfgKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.autowaterdrop.config",
                GLFW.GLFW_KEY_O,
                "key.categories.misc"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 == null || client.field_1687 == null) {
                return;
            }

            final class_746 player = client.field_1724;

            // Exclusions: creative, spectator, elytra, mount
            if (!player.method_5805() || player.method_68878() || player.method_7325() || player.method_6128() || player.method_5765()) {
                resetState();
                return;
            }

            // Ready HUD pre-calculation: do we have water bucket in hotbar?
            boolean hasBucket = InventoryUtil.findBestWaterBucketSlot(player.method_31548(), player.method_31548().field_7545) != -1;

            // Raycast to compute valid surface for HUD readiness
            boolean hasSurface = false;
            if (client.field_1687 != null) {
                class_3965 hit = raycastDown(player, 256.0);
                hasSurface = hit != null && hit.method_17783() == class_239.class_240.field_1332;
            }
            AwdHud.setReady(hasBucket && hasSurface && !player.method_5799());

            boolean onGround = player.method_24828();

            // Open config on key press
            while (cfgKey.method_1436()) {
                client.method_1507(new com.autowaterdrop.client.config.AwdConfigScreen(client.field_1755));
            }
            double vy = player.method_18798().field_1351;

            if (onGround) {
                fallStartY = Double.NaN;
                wasOnGround = true;
            } else {
                if (wasOnGround) {
                    fallStartY = player.method_23318();
                }
                wasOnGround = false;
            }

            // If not falling meaningfully, clear schedule
            if (onGround || vy >= FALL_VELOCITY_THRESHOLD) {
                ticksUntilPlace = -1;
            }

            // Determine fall distance
            double fallDistance = (Double.isNaN(fallStartY) ? 0.0 : (fallStartY - player.method_23318()));

            // Early exit if not above threshold
            if (fallDistance < AwdConfig.get().minFallHeightBlocks) {
                handleDeferredPickup(client);
                return;
            }

            // Must have water bucket in hotbar
            int bestBucketSlot = InventoryUtil.findBestWaterBucketSlot(player.method_31548(), player.method_31548().field_7545);
            if (bestBucketSlot == -1) {
                handleDeferredPickup(client);
                return;
            }

            // If already in water, or in web/slime cancel
            if (player.method_5799() || player.method_6101()) {
                resetState();
                return;
            }

            // Predict impact time and schedule placement
            class_3965 ground = raycastDown(player, 256.0);
            if (ground == null || ground.method_17783() != class_239.class_240.field_1332) {
                handleDeferredPickup(client);
                return;
            }

            double distanceToGround = Math.max(0.0, player.method_23318() - ground.method_17784().field_1351);
            // Estimate ticks to impact using current vy and gravity approx per tick
            // Use simple kinematics with mc gravity ~ -0.08 and velocity dampening 0.98; however, for safety we approximate linearly
            int estimatedTicksToImpact = estimateTicksToImpact(distanceToGround, vy);

            int activationLead = AwdConfig.get().activationLeadTicks;
            if (AwdConfig.get().safeModeExtraTick) activationLead += 1;
            activationLead += getLatencySafetyTicks(client);

            if (estimatedTicksToImpact <= activationLead) {
                // Execute placement now
                if (previousSelectedSlot == -1 && AwdConfig.get().restorePreviousSlot) {
                    previousSelectedSlot = player.method_31548().field_7545;
                }

                if (player.method_31548().field_7545 != bestBucketSlot) {
                    player.method_31548().field_7545 = bestBucketSlot;
                }

                // Try place underfoot or nearest valid neighbor
                boolean placed = PlacementUtil.tryPlaceWater(client, player, ground.method_17777());
                if (placed) {
                    if (AwdConfig.get().showChatOnActivate) {
                        player.method_7353(class_2561.method_43470("Auto WaterDrop: activated"), false);
                    }
                    if (AwdConfig.get().autoPickupTicks > 0) {
                        scheduledPickup = true;
                        pickupDelayTicks = AwdConfig.get().autoPickupTicks;
                    }
                    ticksUntilPlace = -1;
                }
            } else {
                ticksUntilPlace = estimatedTicksToImpact - activationLead;
            }

            handleDeferredPickup(client);
        });

        HudRenderCallback.EVENT.register((context, tickDelta) -> {
            AwdHud.render(context);
        });
    }

    private void handleDeferredPickup(class_310 client) {
        if (scheduledPickup) {
            if (pickupDelayTicks > 0) {
                pickupDelayTicks--;
            } else {
                // Attempt to pick water back up by using the water bucket again
                class_746 player = client.field_1724;
                if (player != null) {
                    client.field_1761.method_2919(player, class_1268.field_5808);
                }
                scheduledPickup = false;
                if (AwdConfig.get().restorePreviousSlot && previousSelectedSlot != -1 && client.field_1724 != null) {
                    client.field_1724.method_31548().field_7545 = previousSelectedSlot;
                }
                previousSelectedSlot = -1;
            }
        }
    }

    private void resetState() {
        ticksUntilPlace = -1;
        scheduledPickup = false;
        pickupDelayTicks = 0;
        previousSelectedSlot = -1;
    }

    private static class_3965 raycastDown(class_746 player, double maxDistance) {
        class_243 start = player.method_5836(1.0f);
        class_243 end = start.method_1031(0, -maxDistance, 0);
        class_3959 ctx = new class_3959(start, end, class_3959.class_3960.field_17558, class_3959.class_242.field_1347, player);
        return player.method_37908().method_17742(ctx);
    }

    private static int estimateTicksToImpact(double distance, double velocityY) {
        // Conservative: assume current speed continues, but clamp to at least 1 tick
        if (distance <= 0) return 0;
        double speed = Math.abs(velocityY);
        if (speed < 0.01) speed = 0.01;
        int linearEstimate = (int)Math.ceil(distance / speed);
        // Add small buffer to account for acceleration
        return Math.max(1, linearEstimate - 1);
    }

    private static int getLatencySafetyTicks(class_310 client) {
        return LatencyUtil.getLatencyTicks(client);
    }
}

