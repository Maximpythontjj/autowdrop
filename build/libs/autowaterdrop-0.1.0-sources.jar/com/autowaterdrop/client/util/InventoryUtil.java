package com.autowaterdrop.client.util;

import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

public final class InventoryUtil {
    private InventoryUtil() {}

    public static int findBestWaterBucketSlot(class_1661 inv, int currentSelected) {
        int bestSlot = -1;
        int bestDistance = Integer.MAX_VALUE;
        for (int slot = 0; slot < 9; slot++) {
            class_1799 stack = inv.method_5438(slot);
            if (stack != null && stack.method_7909() == class_1802.field_8705) {
                int dist = ringDistance(slot, currentSelected);
                if (dist < bestDistance) {
                    bestDistance = dist;
                    bestSlot = slot;
                }
            }
        }
        return bestSlot;
    }

    private static int ringDistance(int a, int b) {
        int diff = Math.abs(a - b);
        return Math.min(diff, 9 - diff);
    }
}

