package com.autowaterdrop.client.util;

import com.autowaterdrop.client.config.AwdConfig;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_746;

public final class PlacementUtil {
    private PlacementUtil() {}

    public static boolean tryPlaceWater(class_310 client, class_746 player, class_2338 basePos) {
        if (client.field_1761 == null) return false;

        // Ensure player actually holds a water bucket
        class_1799 held = player.method_6047();
        if (held == null || held.method_7909() != class_1802.field_8705) {
            // attempt with offhand if present
            held = player.method_6079();
            if (held == null || held.method_7909() != class_1802.field_8705) return false;
        }

        // First try directly above target block
        if (canPlaceAt(player, basePos.method_10084())) {
            if (useOnBlock(client, player, basePos, class_2350.field_11036)) return true;
        }

        if (!AwdConfig.get().searchNeighborPlacements) return false;

        // Try neighbors around basePos to handle thin/unplaceable blocks underfoot
        class_2338[] offsets = new class_2338[] {
            new class_2338(1, 0, 0), new class_2338(-1, 0, 0), new class_2338(0, 0, 1), new class_2338(0, 0, -1),
            new class_2338(1, 0, 1), new class_2338(1, 0, -1), new class_2338(-1, 0, 1), new class_2338(-1, 0, -1)
        };
        for (class_2338 off : offsets) {
            class_2338 candidate = basePos.method_10081(off).method_10084();
            if (canPlaceAt(player, candidate)) {
                // face towards center of candidate
                if (useOnBlock(client, player, candidate.method_10074(), class_2350.field_11036)) return true;
            }
        }
        return false;
    }

    private static boolean canPlaceAt(class_746 player, class_2338 pos) {
        class_2680 state = player.method_37908().method_8320(pos);
        // Allow replacing air and water (for update), avoid solid blocks occupying the space
        return state.method_26215() || state.method_27852(class_2246.field_10382) || state.method_26227().method_15769();
    }

    private static boolean useOnBlock(class_310 client, class_746 player, class_2338 target, class_2350 face) {
        class_243 hitVec = class_243.method_24953(target).method_1031(0, -0.49, 0);
        class_3965 bhr = new class_3965(hitVec, face, target, false);
        class_1269 res = client.field_1761.method_2896(player, class_1268.field_5808, bhr);
        if (res.method_23665()) return true;
        // Try offhand as fallback
        res = client.field_1761.method_2896(player, class_1268.field_5810, bhr);
        return res.method_23665();
    }
}

