package com.autowaterdrop.client.util;

import net.minecraft.class_310;
import net.minecraft.class_634;

public final class LatencyUtil {
    private LatencyUtil() {}

    public static int getLatencyTicks(class_310 client) {
        if (client == null || client.method_1562() == null) return 0;
        class_634 nh = client.method_1562();
        if (client.field_1724 != null && nh.method_2871(client.field_1724.method_5667()) != null) {
            int ping = nh.method_2871(client.field_1724.method_5667()).method_2959(); // ms
            // Convert ms to ticks (50ms per tick), cap to 2 for safety
            return Math.min(2, Math.max(0, (int)Math.round(ping / 50.0)));
        }
        return 0;
    }
}

